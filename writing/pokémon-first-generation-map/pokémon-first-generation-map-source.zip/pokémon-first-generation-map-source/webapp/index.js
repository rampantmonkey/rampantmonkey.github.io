const { locations, gfx } = require('../src/map')

import * as Three from 'three';
import {OrbitControls} from 'three/examples/jsm/controls/OrbitControls.js'

const asciiRenderTarget = (() => {
  const palletize = (n) => {
    switch(n) {
      case 0b00: return ' ';
      case 0b01: return ':';
      case 0b10: return '?';
      case 0b11: return 'X';
    }
  }

  return (iBuffer, iWidth, iHeight) => {
    let out = ''
    for(let h = 0; h < iHeight * 4 * 8; h++) {
      for(let w = 0; w < iWidth * 4 * 8; w++) {
        out += palletize(iBuffer[h * iWidth * 4 * 8 + w])
      }
      out += '\n'
    }
    return out
  }
})();

const boxyScale = (iBuffer, scaleFactor, iWidth, iHeight, oBuffer) => {
  if(!oBuffer || !oBuffer.length) oBuffer = new Uint8Array(iWidth*scaleFactor * iHeight*scaleFactor)
  for(let h=0; h < iWidth; h++) {
    for(let w=0; w < iHeight; w++) {
      for(let sh=0; sh < scaleFactor; sh++) {
        let destRow = h*scaleFactor + sh;
        for(let sw=0; sw < scaleFactor; sw++) {
          let destCol = w*scaleFactor + sw;
          for(let c=0; c < 4; c++) {
            oBuffer[(destRow * width + destCol)*4 + c] = iBuffer[(h*160 + w)*4 + c];
          }
        }
      }
    }
  }
  return oBuffer
}

const canvasRenderTarget = (canvas) => {
  const palletize = (n) => {
    switch(n) {
      case 0b00: return [0xe0, 0xf8, 0xd0, 0xff];
      case 0b01: return [0x88, 0xc0, 0x70, 0xff];
      case 0b10: return [0x34, 0x68, 0x56, 0xff];
      case 0b11: return [0x08, 0x18, 0x20, 0xff];
    }
  }

  return (iBuffer, iWidth, iHeight) => {
    let cvs = document.createElement('canvas')
    let ctx = cvs.getContext('2d')
    cvs.width = iWidth
    cvs.height = iHeight
    let ctx_data = ctx.createImageData(iWidth * 32, iHeight * 32)
    let outCursor = 0
    for(let h = 0; h < iHeight * 4 * 8; h++) {
      for(let w = 0; w < iWidth * 4 * 8; w++) {
        for(let c = 0; c < 4; c++) {
          let pixel = palletize(iBuffer[h * iWidth * 4 * 8 + w])
          ctx_data.data[outCursor] = pixel[c]
          outCursor++
        }
      }
    }

    canvas.width = iWidth * 32
    canvas.height = iHeight * 32

    return ctx_data
  }
}

const textureRenderTarget = (parent) => {
  const palletize = (n) => {
    switch(n) {
      case 0b00: return [0xe0, 0xf8, 0xd0, 0xff];
      case 0b01: return [0x88, 0xc0, 0x70, 0xff];
      case 0b10: return [0x34, 0x68, 0x56, 0xff];
      case 0b11: return [0x08, 0x18, 0x20, 0xff];
    }
  }

  return (iBuffer, iWidth, iHeight, location) => {
    const data = new Uint8Array(iWidth * iHeight * 32 * 32 * 4)
    let cursor = 0
    for(let h = 0; h < iHeight * 4 * 8; h++) {
      for(let w = 0; w < iWidth * 4 * 8; w++) {
        let pixel = palletize(iBuffer[h * iWidth * 4 * 8 + w])
        for(let c = 0; c < 4; c++) {
          data[cursor] = pixel[c]
          cursor++
        }
      }
    }

    const texture = new Three.DataTexture(data, iWidth*32, iHeight*32)
    texture.flipY = true
    texture.needsUpdate = true
    const geometry = new Three.PlaneGeometry(iWidth, iHeight)
    const material = new Three.MeshBasicMaterial({map: texture})
    const plane = new Three.Mesh(geometry, material)
    plane.name = location.Name
    return plane
  }
}

const renderer = ((gfx) => (renderTarget) => (location) => {
  set = gfx[location.blockset.toLowerCase()]
  let blocks = []
  location.mapData.forEach(idx => blocks.push(set.blocks[idx]))
  // Width * Height * Block Width * Block Height * Tile Width * Tile Height
  let buf = typeof window === 'undefined'
          ? Buffer.alloc(location.width * location.height * 4 * 4 * 8 * 8)
          : new Uint8Array(location.width * location.height * 4 * 4 * 8 * 8)
  let writeCursor = 0
  for(let h = 0; h < location.height; h++) {
    for(let blockH = 0; blockH < 4; blockH++) {
      for(let tileH = 0; tileH < 8; tileH++) {
        for(let w = 0; w < location.width; w++) {
          let block = blocks[h * location.width + w]
          if(block === undefined) break;
          for(let blockW = 0; blockW < 4; blockW++) {
            let tileOffset = block[blockH * 4 + blockW] * 8 * 2;
            for(let tileRowByte = 0; tileRowByte < 2; tileRowByte++) {
              for(let tileBitshift = 6; tileBitshift >= 0; tileBitshift -= 2) {
                buf[writeCursor] = (set.tiles[tileOffset + tileH*2 + tileRowByte] >> tileBitshift) & 0b11
                writeCursor++
              }
            }
          }
        }
      }
    }
  }

  return renderTarget(buf, location.width, location.height, location)
})(gfx);

const locationSelector = (locations) => (parent) => (changeCb) => {
  const select = document.createElement('select')
  locations.forEach(l => {
    const opt = document.createElement('option')
    opt.value = l.CONSTANT_NAME
    opt.innerText = l.Name
    select.appendChild(opt)
  })

  select.addEventListener('change', (ev) => changeCb(locations.find(l => l.CONSTANT_NAME == ev.target.value)))
  parent.appendChild(select)
}

window.addEventListener('load', () => {
  document.querySelectorAll('[data-poke-map-ascii]').forEach(el => {
    const renderLocation = renderer(asciiRenderTarget)
    let out = document.createElement('pre')
    out.classList.add('ascii')
    out.innerText = renderLocation(locations[0])
    locationSelector(locations)(el)((l) => out.innerText = renderLocation(l))
    el.appendChild(out)
  })

  document.querySelectorAll('[data-poke-map-canvas]').forEach(el => {
    let out = document.createElement('canvas')
    const renderLocation = renderer(canvasRenderTarget(out))
    let ctx = out.getContext('2d')
    ctx.putImageData(renderLocation(locations[0]), 0, 0)
    locationSelector(locations)(el)((l) => ctx.putImageData(renderLocation(l), 0, 0))
    el.appendChild(out)
  })

  document.querySelectorAll('[data-poke-map-three]').forEach(el => {
    const pointer = new Three.Vector2()
    const raycaster = new Three.Raycaster()
    let mousing = false
    let zCutoff = 21
    let warpsOn = false

    el.addEventListener('mouseenter', () => mousing = true)
    el.addEventListener('mouseleave', () => mousing = false)
    const hudEl = document.createElement('div')
    hudEl.classList.add('hud')
    const pickedLabel = document.createElement('span')
    hudEl.appendChild(pickedLabel)
    el.appendChild(hudEl)
    const renderLocation = renderer(textureRenderTarget(el))
    const planes = locations.map(renderLocation)
    const r = new Three.WebGLRenderer()
    r.setClearColor(new Three.Color(0xe0f8d0))
    r.autoClear = true
    r.setSize(el.clientWidth, el.clientWidth)
    el.appendChild(r.domElement)

    const scene = new Three.Scene()
    const camera = new Three.PerspectiveCamera(45, 1, 1, 10000)
    camera.position.x = 50
    camera.position.y = 40
    camera.position.z = 275

    const controls = new OrbitControls(camera, r.domElement)
    controls.mouseButtons = {
      LEFT: Three.MOUSE.PAN,
      MIDDLE: Three.MOUSE.DOLLY,
      RIGHT: Three.MOUSE.ROTATE,
    }
    controls.target = new Three.Vector3(camera.position.x, camera.position.y, 0)
    controls.update()
    function animate() {
      if(mousing) {
        raycaster.setFromCamera(pointer, camera)
        for(let i=0, l=scene.children.length; i < l; i++) {
          scene.children[i].material.color.set(0xffffff)
        }
        const intersects = raycaster.intersectObjects(scene.children)
        if(intersects.length === 0) { hudEl.innerText = '' }
        else {
          intersects.sort((a, b) => a.object.position.z < b.object.position.z)
          for(let i=0; i < intersects.length; i++) {
            if(intersects[i].object.visible) {
              intersects[i].object.material.color.set(0x88c070)
              hudEl.innerText = intersects[i].object.name
              break;
            }
          }
        }
      } else {
        hudEl.innerText = ''
      }
      r.render(scene, camera)
    }

    controls.addEventListener('change', animate)
    window.addEventListener('pointermove', (ev) => {
      pointer.x = (ev.clientX / el.clientWidth) * 2 - 1
      pointer.y = - (ev.clientY / el.clientWidth) * 2 + 1
      animate()
    })
    window.addEventListener('resize', animate);

    let toPosition = [[null, locations[0], null, 0]]
    let toPositionWarp = []
    let positions = {}
    while(toPosition.length > 0) {
      let [src, l, dir, offset] = toPosition.pop()

      let x = 0
      let y = 0
      let z = 0
      if(src) {
        switch(dir) {
          case 'north': {
            y = positions[src.CONSTANT_NAME].y + (src.height + l.height) / 2
            x = positions[src.CONSTANT_NAME].x - (src.width - l.width) / 2 + offset
          } break;
          case 'south': {
            y = positions[src.CONSTANT_NAME].y - (src.height + l.height) / 2
            x = positions[src.CONSTANT_NAME].x - (src.width - l.width) / 2 + offset
          } break;
          case 'east': {
            y = positions[src.CONSTANT_NAME].y + (src.height - l.height) / 2 - offset
            x = positions[src.CONSTANT_NAME].x + (src.width + l.width) / 2
          } break;
          case 'west': {
            y = positions[src.CONSTANT_NAME].y + (src.height - l.height) / 2 - offset
            x = positions[src.CONSTANT_NAME].x - (src.width + l.width) / 2
          } break;
        }
      }

      positions[l.CONSTANT_NAME] = {x, y, z}
      if(l.connections.north) {
        let d = l.connections.north.destination
        let dest = locations.find(ll => ll.CONSTANT_NAME == d)
        if(!positions[d]) { toPosition.push([l, dest, 'north', l.connections.north.offset || 0]) }
      }
      if(l.connections.south) {
        let d = l.connections.south.destination
        let dest = locations.find(ll => ll.CONSTANT_NAME == d)
        if(!positions[d]) { toPosition.push([l, dest, 'south', l.connections.south.offset || 0]) }
      }
      if(l.connections.east) {
        let d = l.connections.east.destination
        let dest = locations.find(ll => ll.CONSTANT_NAME == d)
        if(!positions[d]) { toPosition.push([l, dest, 'east', l.connections.east.offset || 0]) }
      }
      if(l.connections.west) {
        let d = l.connections.west.destination
        let dest = locations.find(ll => ll.CONSTANT_NAME == d)
        if(!positions[d]) { toPosition.push([l, dest, 'west', l.connections.west.offset || 0]) }
      }

      l.warps.forEach(w => w.dest == 'LAST_MAP' ? null : toPositionWarp.push([l, w]))
    }

    while(toPositionWarp.length > 0) {
      let [src, warp] = toPositionWarp.pop()
      let dest = locations.find(l => l.CONSTANT_NAME == warp.dest)
      if(!dest) { continue }
      dest.warps.forEach(w => {
        if(w.dest == 'LAST_MAP') { return }
        if(w.dest == dest.CONSTANT_NAME) { return } // Pretty sure that Saffron Gym and Silph Co are the only examples of this branch.
        if(positions[w.dest]) { return }
        toPositionWarp.push([dest, w])
      })
      let nudge = {x: 0, y: 0, z: 1}
      switch(dest.CONSTANT_NAME) {
        case 'REDS_HOUSE_1F'             : { nudge.x = -1; nudge.y = 2; } break;
        case 'BLUES_HOUSE'               : { nudge.x = 1; nudge.y = 2; } break;
        case 'OAKS_LAB'                  : { nudge.x = 1; nudge.y = -2; } break;
        case 'ROUTE_22_GATE'             : { nudge.x = -2; nudge.y = 3; } break;
        case 'ROUTE_2_GATE'              : { nudge.y = 7} break;
        case 'ROUTE_2_TRADE_HOUSE'       : { nudge.y = 7 } break;
        case 'VIRIDIAN_FOREST'           : { nudge.y = 14; nudge.z = 0;} break;
        case 'VIRIDIAN_FOREST_SOUTH_GATE': { nudge.x = -6; nudge.y = 5;} break;
        case 'VIRIDIAN_FOREST_NORTH_GATE': { nudge.x = -12; nudge.y = 17; } break;
        case 'VIRIDIAN_GYM'              : { nudge.x = 3; nudge.y = 4; } break;
        case 'VIRIDIAN_NICKNAME_HOUSE'   : { nudge.x = -3; nudge.y = 5; } break;
        case 'VIRIDIAN_SCHOOL_HOUSE'     : { nudge.x = -3; nudge.y = 4; } break;
        case 'VIRIDIAN_MART'             : { nudge.y = 5.5; } break;
        case 'VIRIDIAN_POKECENTER'       : { nudge.x = 1; nudge.y = 4; } break;
        case 'INDIGO_PLATEAU_LOBBY'      : { nudge.x = 2; nudge.y = 2; } break;
        case 'LORELEIS_ROOM'             : { nudge.y = 6; nudge.z = 0; } break;
        case 'BRUNOS_ROOM'               : { nudge.y = 6; nudge.z = 0; } break;
        case 'AGATHAS_ROOM'              : { nudge.y = 6; nudge.z = 0; } break;
        case 'LANCES_ROOM'               : { nudge.x = -6; nudge.y = 1; nudge.z = -1; } break;
        case 'CHAMPIONS_ROOM'            : { nudge.x = -0.75; nudge.y = 3.25; nudge.z = 0; } break;
        case 'HALL_OF_FAME'              : { nudge.x = 1.5; nudge.y = 1; nudge.z = 0; } break;
        case 'VICTORY_ROAD_1F'           : { nudge.x = 3; nudge.y = 18; } break;
        case 'VICTORY_ROAD_2F'           : { nudge.x = 3; nudge.y = 18; nudge.z = 2; } break;
        case 'DIGLETTS_CAVE_ROUTE_2'     : { nudge.y = 8; nudge.z = -1; } break;
        case 'DIGLETTS_CAVE_ROUTE_11'    : { nudge.z = -1; } break;
        case 'DIGLETTS_CAVE'             : { nudge.x = 50; nudge.y = -40; nudge.z = -1; } break;
        case 'MUSEUM_1F'                 : { nudge.x = -0.5; nudge.y = 5; } break;
        case 'MUSEUM_2F'                 : { nudge.x = -4; nudge.y = -1; } break;
        case 'PEWTER_GYM'                : { nudge.x = -4; nudge.y = 2.5; } break;
        case 'PEWTER_MART'               : { nudge.x = -3; nudge.y = 2.5; } break;
        case 'PEWTER_NIDORAN_HOUSE'      : { nudge.y = 4; } break;
        case 'PEWTER_POKECENTER'         : { nudge.x = 2.5; nudge.y = 2; } break;
        case 'PEWTER_SPEECH_HOUSE'       : { nudge.x = -3; nudge.y = 4; } break;

      }
      if(positions[src.CONSTANT_NAME].z == 0) {
        var p = {x: positions[src.CONSTANT_NAME].x + warp.row/2 - dest.width/2 - src.width/4 + nudge.x
                ,y: positions[src.CONSTANT_NAME].y - warp.col/2 + dest.height/2 + src.height/4 + nudge.y
                ,z: positions[src.CONSTANT_NAME].z + 2*nudge.z
                ,w: true
                }
      } else {
        var p = {x: positions[src.CONSTANT_NAME].x + nudge.x
                ,y: positions[src.CONSTANT_NAME].y + nudge.y
                ,z: positions[src.CONSTANT_NAME].z + 2*nudge.z
                ,w: true
                }
      }
      positions[warp.dest] = p
    }

    let warpPlanes = []

    Object.entries(positions).forEach(([k, v]) => {
      let idx = locations.findIndex(l => l.CONSTANT_NAME == k)
      let p = planes[idx]
      p.position.x = v.x
      p.position.y = v.y
      p.position.z = v.z
      p.visible = v.z < zCutoff
      if(v.w) {
        warpPlanes.push(p)
        p.visible = false
      }
      scene.add(p)
    })

    animate()

    document.addEventListener('keyup', (ev) => {
      switch(ev.key) {
        case 'r': {
          camera.position.x = 50
          camera.position.y = 40
          camera.position.z = 275
          controls.target = new Three.Vector3(camera.position.x, camera.position.y, 0)
          controls.update()
          zCutoff = 21
          planes.forEach(p => p.visible = p.position.z < zCutoff)
          animate()
        } break;
        case '=':
        case '+': {
          zCutoff = Math.min(zCutoff + 2.0, 21)
          planes.forEach(p => p.visible = p.position.z < zCutoff)
          animate()
        } break;
        case '-': {
          zCutoff = Math.max(zCutoff - 2.0, -3)
          planes.forEach(p => p.visible = p.position.z < zCutoff)
          animate()
        } break;
        case 'w': {
          warpsOn = !warpsOn
          warpsOn ? warpPlanes.forEach(p => p.visible = p.position.z < zCutoff)
                  : warpPlanes.forEach(p => p.visible = false)
          animate()
        } break;
      }
    })
  })
})

// TODO: Artistic improvements
// - Warp locations need to be manually positioned (or at least offset) due to the different scale from the overworld. Too many overlapping locations.
// - Figure out which locations should be above ground and which should be below ground
// - Transparency for some of the floating layers which are not fully populated.


// Future Keymappings
// - n -> toggle navmesh
// - i -> toggle interiors (i.e. not the routes and cities)
// - o -> toggle trainers and items
