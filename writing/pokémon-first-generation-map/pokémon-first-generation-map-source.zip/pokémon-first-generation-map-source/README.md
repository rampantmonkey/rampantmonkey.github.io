# Mapping Pokemon

Starting from the pokered dissassembled game, can I build a 2.5d version of the map with threes.js?

There are a few variations on the data I would like to build.

a. tile map rendered as layers (i.e. the actual pixels from the game)
b. a nav mesh to show connections between locations (basis for the AI pathfinding and would probably make a cool teeshirt)
c. Item and NPC location overlays with game state triggers (so that I can dynamically adjust the map and navmesh based on story events and so that the AI knows where items/goals exist in the world).


## Pokered data
I first saw an overview of the rendering process on Peter Hajas's website, [Parsing Pokemon Red and Blue Maps](http://peterhajas.com/blog/pokemon_rb_map_parsing.html).

The map is stored in nested layers of detail (location, blocks of 4x4 tiles, tiles of 8x8 pixels).

The process goes something like this:
1. Start by finding the location metadata in `data/maps/headers`.
2. Extract the tileset from this header.
3. Grab the blockset from `gfx/blocksets`.
4. Find the map dimensions in `constants/map_constants.asm` (height, width)
5. Bitwise mangling to render each tile.

## Milestones
- Tile Map
  1. Render Pallet Town using unicode characters and compare to Peter's output.
  2. Render every location validated with a visual sanity check.
  3. Render to HTML canvas.
  4. Stitch together whole overworld map.
  5. Render as 3d object (a plane with orbit/pan controls like a terrible cad program).
  6. Render indoor locations as layer above overworld (below overworld where thematically appropriate like Digglet's Cave).
- Nav Mesh
  1. Gather data to determine which tiles are walkable.
  2. Draw nav mesh for Pallet Town overworld.
  3. Draw nav mesh for Pallet Town interiors.
  4. Connect all Pallet Town nav meshes.
  5. Repeat for each location.
  6. Create a poster and t-shirt.
- Objects
  1. Gather data to place objects.
  2. Find correct sprites for each object.
  3. Story event triggers.
  4. ???
