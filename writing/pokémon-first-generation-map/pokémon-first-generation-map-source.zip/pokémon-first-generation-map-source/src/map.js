const rawLocations = require('../src/locations.json')
const rawGfx = require('../src/gfx.json')

const deserializeBuffers = (obj) => {
  if(obj.hasOwnProperty('type') && obj.type === 'Buffer' && obj.hasOwnProperty('data')) {
    return typeof window === 'undefined' ? Buffer.from(obj.data) : Uint8Array.from(obj.data)
  } else {
    Object.keys(obj).forEach(key => {
      if(typeof obj[key] === 'object') {
        if(Array.isArray(obj[key])) {
          obj[key] = obj[key].map(deserializeBuffers)
        } else {
          obj[key] = deserializeBuffers(obj[key])
        }
      }
    })
    return obj
  }
}

const locations = deserializeBuffers(rawLocations).filter(l => !l.CONSTANT_NAME.startsWith('UNUSED') && !l.CONSTANT_NAME.endsWith('COPY'))
const gfx = deserializeBuffers(rawGfx)

module.exports = { locations, gfx }

