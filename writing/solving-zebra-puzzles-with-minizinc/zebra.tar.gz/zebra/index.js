if(process.argv.includes('repl')) {
  require('./lib/repl')();
} else {
  const solve = require('./lib/solver');
  (async () => {
    console.log(await solve('puzzles/who-owns-the-crocodile.pdf'))
  })();
}
