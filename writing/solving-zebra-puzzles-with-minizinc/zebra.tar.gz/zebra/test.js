const assert = require('assert')

const solve = require('./lib/solver')

const util = require('util')

const assertSolves = async (path, expected) => {
  let solution = await solve(path)
  assert.deepEqual(solution, expected)
}

(async () => {
  await assertSolves(
   'puzzles/who-owns-the-crocodile.pdf',
   {
     "Color": [ "lilac", "blue", "pink", "green", "purple" ],
     "Name": [ "Lucy", "Jo", "Hannah", "Jessica", "Georgina" ],
     "Chocolate": [ "Crunchies", "Wispa Bites", "Dairy Milk", "Milky Bars", "Boost" ],
     "Pet": [ "rabbit", "puppy", "crocodile", "horse", "hamster" ],
     "Hobby": [ "tennis", "horse riding", "ten_pin bowling", "skiing", "swimming" ],
     "Holiday": [ "Maldives", "Tobago", "Florida", "Australia", "Canada" ],
   })
})();

const extract = require('./lib/pdf')
const assertExtractCategoriesCardinality = async (path) => {
  let extraction = await extract(path)
  assert(extraction.categories, 'extracted puzzle does not have any categories')
  assert(Object.keys(extraction.categories).length === 6, `extracted puzzle has ${Object.keys(extraction.categories).length} categories not 6. Found ${Object.keys(extraction.categories)}`)
  Object.keys(extraction.categories).forEach(category => {
    assert(extraction.categories[category].length === 5, `the ${category} extracted from the pdf has ${extraction.categories[category].length} not 5. Found ${extraction.categories[category]}`)
  })
}

const assertExtractCluesCardinality = async (path) => {
  let extraction = await extract(path)
  assert(extraction.clues, 'extracted puzzle does not have any clues')
  assert(extraction.clues.length < 30, `extracted puzzle has too many clues. Found ${extraction.clues.length}.`)
  assert(extraction.clues.length > 5, `extracted puzzle has too few clues. Found ${extraction.clues.length}.`)
}

const assertForAllPuzzles = async (predicate) => {
  const fs = require('fs')
  const paths = fs.readdirSync('puzzles')
  const results = await Promise.all(
    paths.filter(p => !p.includes('basic-') && !p.includes('movies-night') && !p.includes('einstein')) // These puzzles have fewer than 5 categories.
         .map((p) => {
           return predicate(`puzzles/${p}`)
           .then(() => { return { path: p, pass: true } })
           .catch((e) => { return { path: p, pass: false, msg: e } })
         }))


  const failingCases = results.filter(r => !r.pass)
  assert(failingCases.length === 0, `Unable to extract a puzzle from some of the pdfs ${failingCases}`)
}

(async () => { // Test PDF extraction
  await assertForAllPuzzles(assertExtractCategoriesCardinality)
  await assertForAllPuzzles(assertExtractCluesCardinality)
})();

(() => { // Test Parsing with some clues manually extracted from the 'Who Owns the Crocodile' puzzle
  const { tag, parse, analyze, simplify } = require('./lib/parse')
  const C = require('./lib/constraints')

  let cases = [
  { clue: 'Jo likes the Wispa Bites.'
  , expected: [C.Is, 'Jo', 'Wispa Bites']
  },
  { clue: 'The person with the Hamster likes Swimming.'
  , expected: [C.Is, 'Hamster', 'Swimming']
  },
  { clue: 'Hannah eats Dairy Milk.'
  , expected: [C.Is, 'Hannah', 'Dairy Milk']
  },
  { clue: 'Jessica is on the left of Georgina.'
  , expected: [C.Left, 'Jessica', 'Georgina']
  },
  { clue: 'Lucy is the first on the left.'
  , expected: [C.Is, 'Lucy', 1]
  },
  { clue: 'The first on the right likes Swimming.'
  , expected: [C.Is, 5, 'Swimming']
  },
  { clue: 'The person who eats Milky Bars owns a Horse.'
  , expected: [C.Is, 'Milky Bars', 'Horse']
  },
  { clue: 'The person in the middle eats Dairy Milk.'
  , expected: [C.Is, 'middle', 'Dairy Milk']
  },
  { clue: 'Jessica likes Green.'
  , expected: [C.Is, 'Jessica', 'Green']
  },
  { clue: 'The person on the left of the middle wants to go to Tobago.'
  , expected: [C.Is, 2, 'Tobago']
  },
  { clue: 'The person who wants to go to the Maldives likes Lilac.'
  , expected: [C.Is, 'Maldives', 'Lilac']
  },
  { clue: 'The person who likes Wispa Bites sits next to the person who wants to go to Florida.'
  , expected: [C.NextTo, 'Wispa Bites', 'Florida']
  },
  { clue: 'The person who likes Pink wants to go to Florida.'
  , expected: [C.Is, 'Pink', 'Florida']
  },
  { clue: 'The person who sits first on the left likes Lilac.'
  , expected: [C.Is, 1, 'Lilac']
  },
  { clue: 'The girl that likes Blue owns a Puppy.'
  , expected: [C.Is, 'Blue', 'Puppy']
  },
  { clue: 'The person who likes Skiing sits next to the person who has a Hamster.'
  , expected: [C.NextTo, 'Skiing', 'Hamster']
  },
  { clue: 'The girl on the right of the girl who likes Tennis likes Horse riding.'
  , expected: [C.Right, 'Horse riding', 'Tennis']
  },
  { clue: 'The girl next to the girl who likes Milky Bars likes Boost.'
  , expected: [C.NextTo, 'Milky Bars', 'Boost']
  },
  { clue: 'The girl who likes Purple wants to go to Canada.'
  , expected: [C.Is, 'Purple', 'Canada']
  },
  { clue: 'The girl who likes Crunchies owns a Rabbit.'
  , expected: [C.Is, 'Crunchies', 'Rabbit']
  },
  { clue: 'The girl who likes Skiing sits next to the girl who plays Ten_pin bowlings.'
  , expected: [C.NextTo, 'Skiing', 'Ten_pin bowlings']
  },
  { clue: 'Jessica wants to go to Australia.'
  , expected: [C.Is, 'Jessica', 'Australia']
  },
  ]

  let results = cases.map(c => {
    let result = { clue: c.clue, pass: null }
    try {
      let computed = simplify(analyze(parse(tag({clues: [c.clue]}))))
      assert.deepEqual(computed.clues[0].simplified, c.expected, `Expected ${c.expected} to deep equal ${util.inspect(computed, {depth: null})}`)
      result.pass = true
    } catch(e) {
      result.pass = false
      result.msg = e
    }
    return result
  })

  const failingCases = results.filter(r => !r.pass)
  assert(failingCases.length === 0, `Unable to parse ${failingCases.length} of the ${cases.length} clues ${util.inspect(failingCases, {depth: null})}`)
})();
