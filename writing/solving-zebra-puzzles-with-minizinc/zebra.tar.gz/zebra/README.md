# Zebra Puzzles

working through the zebra puzzles at brainzilla.org with minizinc.

## Usage
To solve the puzzle run minizinc with the following command. Substitute the puzzle name as necessary.

    minizinc --solver Gecode fancy_hotels.mzn
